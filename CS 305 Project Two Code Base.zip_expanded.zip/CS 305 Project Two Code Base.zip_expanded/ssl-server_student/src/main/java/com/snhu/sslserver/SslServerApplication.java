package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.time.Instant;
import java.nio.charset.StandardCharsets;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{
//Add hash function to return the checksum value for the data string    
    @GetMapping("/hash")
    public String myHash(){
    	String name = "Nicholas Deniz";  //Name
    	String unique = name + " - " + Instant.now(); //Unique data
    	
    	try {
    		MessageDigest md = MessageDigest.getInstance("SHA-256"); //Oracle standard name
    		byte[] digest = md.digest(unique.getBytes(StandardCharsets.UTF_8));
        	String hex = bytesToHex(digest);  // SHA-256
    		
    		return "Checksum Verification<br>" + "Name:" + name + "<br>"+ "Unique Data: " 
    		+ unique + "<br>" + "SHA-256: " + hex;
    			
    	} catch (Exception e) {
    		return "Error: " + e.getMessage();
    	}
    }
       
    private static String bytesToHex(byte[] bytes) {
    	StringBuilder sb = new StringBuilder(bytes.length * 2);
    	for (byte b : bytes) 
    	sb.append(String.format("%02x", b));
    	return sb.toString();
    	}
}